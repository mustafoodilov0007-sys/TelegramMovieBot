from aiogram import Bot, F, Router
from aiogram.types import CallbackQuery

from config import ADMIN_ID
from app.database.db import add_user, get_channels
from app.keyboards.main_menu import main_menu_keyboard
from app.keyboards.subscription import subscription_keyboard

router = Router()


@router.callback_query(F.data == "check_sub")
async def check_subscription(callback: CallbackQuery, bot: Bot):
    channels = get_channels()
    missing = []

    for ch in channels:
        channel_id = ch[1]
        try:
            member = await bot.get_chat_member(chat_id=channel_id, user_id=callback.from_user.id)
            is_subscribed = member.status in ("member", "administrator", "creator")
        except Exception:
            is_subscribed = False
        if not is_subscribed:
            missing.append(ch)

    if not missing:
        add_user(callback.from_user.id, callback.from_user.username, callback.from_user.full_name)
        await callback.message.edit_text("✅ Barcha kanallarga obuna tasdiqlandi!")
        is_admin = callback.from_user.id == ADMIN_ID
        await callback.message.answer(
            "🔎 Endi kino yoki multfilm nomini/kodini yuboring, "
            "yoki quyidagi menyudan foydalaning.",
            reply_markup=main_menu_keyboard(is_admin=is_admin),
        )
    else:
        word = "kanalga" if len(missing) == 1 else "kanallarga"
        try:
            await callback.message.edit_text(
                f"⚠️ Siz hali quyidagi {word} obuna bo'lmagansiz:",
                reply_markup=subscription_keyboard(missing),
            )
        except Exception:
            pass
        await callback.answer("❌ Hali barcha kanallarga obuna bo'lmagansiz.", show_alert=True)
